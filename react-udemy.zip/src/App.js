import React from "react";
import 'bulma/css/bulma.css';
import BookApp from "./components/BookApp/BookApp";

function App() {
  return (
    <div>
      <BookApp />
    </div>
  );
}

export default App;
